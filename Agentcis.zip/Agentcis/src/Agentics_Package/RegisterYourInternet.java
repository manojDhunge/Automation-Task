package Agentics_Package;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;

public class RegisterYourInternet {
	private static WebElement element = null;
	
	public static WebElement Register_Your_Internet(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		element=driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/header/div/div/div[2]/nav/div/ul/li[5]/a"));
		return element;
	}
	
	public static WebElement First_Name(WebDriver driver)
	{
		element=driver.findElement(By.id("agilefield-1"));
		return element;
	}
	
	public static WebElement Last_Name(WebDriver driver)
	{
		element=driver.findElement(By.id("agilefield-2"));
		return element;
	}
	
	public static WebElement email(WebDriver driver)
	{
		element=driver.findElement(By.id("agilefield-3"));
		return element;
	}
	
	public static WebElement Business_Name(WebDriver driver)
	{
		element=driver.findElement(By.id("agilefield-4"));
		return element;
	}
	public static WebElement Captcha(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[2]/div[3]/div[1]/div/div/span/div[5]"));
		return element;
	
	}
	public static WebElement Submit(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[7]/div[1]/input"));
		return element;
	}
	
	public static WebElement Assertion_Message(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/form/div[7]/div[2]"));
		return element;
	}

}
