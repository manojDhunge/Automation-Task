package Agentics_Package;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class AgenticsTestFunctions {
		  
	   public static void main(String[] args) throws InterruptedException {
	   
		   WebDriver driver;
		   System.setProperty("webdriver.gecko.driver", "D:\\Drivers\\geckodriver.exe");
		   driver = new FirefoxDriver();
	      driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	      driver.navigate().to("http://agentcis:e5FU2LeNtx@wordpress.agentcis.com/");
	      driver.manage().window().maximize();
	      Alert alert = driver.switchTo().alert();
	                alert.accept();
	      
	      //navigation to feature page
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);          
	      AgenticsTestObject.Navigation_FeaturePage(driver).click();
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	       	       	        
	      //navigation to solutions page
	      AgenticsTestObject.Navigation_SolutionsPage(driver).click();
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
	      //navigation to community page
	      CommunitySearchForm.Navigation_CommunityPage(driver).click();
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      
	      //Community search form for student
	      CommunitySearchForm.Community_Student_Search(driver).sendKeys("Student");
	      CommunitySearchForm.Community_Student_Search(driver).sendKeys(Keys.ENTER);
	      
	      
	      driver.close();
	      
	     
	   }
}
