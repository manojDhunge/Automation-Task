package Agentics_Package;

import org.openqa.selenium.*;

public class AgenticsTestObject {
	private static WebElement element = null;
	
	public static WebElement Navigation_FeaturePage(WebDriver driver)
	{
		
		element=driver.findElement(By.id("menu-item-48"));
		return element;
	}

	public static WebElement Navigation_SolutionsPage(WebDriver driver)
	{
		
		element=driver.findElement(By.id("menu-item-47"));
		return element;
	}
	
	
}
