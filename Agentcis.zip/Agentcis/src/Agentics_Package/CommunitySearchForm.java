package Agentics_Package;


import org.openqa.selenium.*;
public class CommunitySearchForm {
	private static WebElement element = null;
	
	public static WebElement Navigation_CommunityPage(WebDriver driver)
	{
		
		element=driver.findElement(By.id("menu-item-995"));
		return element;
		
	}
	public static WebElement Community_Student_Search(WebDriver driver)
	{
		
		element=driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div/div[2]/aside/section[1]/form/label/input"));
		return element;
	}
	

}
