package Agentics_Package;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class RegisterYourInternetCallFunction {
	 public static void main(String[] args) {
		   
		   WebDriver driver;
		   System.setProperty("webdriver.gecko.driver", "D:\\Drivers\\geckodriver.exe");
		   driver = new FirefoxDriver();
	      driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	      driver.navigate().to("http://agentcis:e5FU2LeNtx@wordpress.agentcis.com/");
	      driver.manage().window().maximize();
	      Alert alert = driver.switchTo().alert();
	                alert.accept();
	                
	                RegisterYourInternet.Register_Your_Internet(driver).click();
	                RegisterYourInternet.First_Name(driver).sendKeys("Soni");
	                RegisterYourInternet.Last_Name(driver).sendKeys("Shrestha");
	                RegisterYourInternet.email(driver).sendKeys("soni.shretha@intercept.co");
	                RegisterYourInternet.Business_Name(driver).sendKeys("Intercept Co");
	                RegisterYourInternet.Submit(driver).click();
	                String i= RegisterYourInternet.Assertion_Message(driver).getText();
	                System.out.println(i);
	                
	 }

}
